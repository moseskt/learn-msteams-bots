const WelcomeCard = require("./WelcomeCard.json");

export default WelcomeCard;
